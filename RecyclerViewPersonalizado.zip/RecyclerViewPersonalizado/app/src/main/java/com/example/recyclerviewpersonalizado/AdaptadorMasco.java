package com.example.recyclerviewpersonalizado;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdaptadorMasco
        extends RecyclerView.Adapter<AdaptadorMasco.ViewHolderMasco>
        implements View.OnClickListener {


    ArrayList<MascotaVo> listaMascotas;
    private View.OnClickListener listener;
    private View.OnClickListener listener2;



    public AdaptadorMasco(ArrayList<MascotaVo> listaMascotas) {
        this.listaMascotas = listaMascotas;
    }

    @Override
    public ViewHolderMasco onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.iem_list_masco, null, false);
        view.setOnClickListener(this);
        view.setOnClickListener(this);


        return new ViewHolderMasco(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderMasco holder, int position) {
        holder.etiNombre.setText(listaMascotas.get(position).getNombre());
        holder.foto.setImageResource(listaMascotas.get(position).getFoto());


    }

    @Override
    public int getItemCount() {

        return listaMascotas.size();
    }



    public void setOnClickListener(View.OnClickListener listener){
        this.listener=listener;
    }



    @Override
    public void onClick(View view) {
        if(listener!=null){
            listener.onClick(view);

        }

    }

    public class ViewHolderMasco extends RecyclerView.ViewHolder {

        TextView etiNombre;
        ImageView foto;
        ImageButton btnLike;


        public ViewHolderMasco(@NonNull View itemView) {
            super(itemView);
            etiNombre=(TextView) itemView.findViewById(R.id.idNombre);
            foto= (ImageView) itemView.findViewById(R.id.idImagen);
            btnLike=(ImageButton) itemView.findViewById(R.id.btnLike);
        }
    }
}
