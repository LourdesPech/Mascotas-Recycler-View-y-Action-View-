package com.example.recyclerviewpersonalizado;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityContacto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
