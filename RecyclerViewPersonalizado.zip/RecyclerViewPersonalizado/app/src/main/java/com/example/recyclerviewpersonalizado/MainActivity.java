package com.example.recyclerviewpersonalizado;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<MascotaVo> listaMascotas;
    RecyclerView recyclerMascotas;
    ImageButton btnLike, btnLike2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listaMascotas=new ArrayList<>();
        recyclerMascotas=findViewById(R.id.RecyclerId);
        recyclerMascotas.setLayoutManager(new LinearLayoutManager(this));


        llenarMascotas();
        AdaptadorMasco adapter=new AdaptadorMasco(listaMascotas);

        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(),
                        "Selección:"+listaMascotas.get
                                (recyclerMascotas.getChildAdapterPosition(view))
                                .getNombre(),Toast.LENGTH_SHORT).show();
            }



        });


        recyclerMascotas.setAdapter(adapter);

    }
        //menu de opciones
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_opciones, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.mAbout:
                Intent intent=new Intent(this, ActivityAbout.class);
                startActivity(intent);
                break;

            case R.id.mContacto:
                Intent intent2=new Intent(this, ActivityContacto.class);
                startActivity(intent2);
                break;

            case R.id.mFavorito:
                Intent intent3=new Intent(this, ActivityFavorito.class);
                startActivity(intent3);
                break;

        }
        return super.onOptionsItemSelected(item);

    }




            private void llenarMascotas() {
        listaMascotas.add(new MascotaVo("Boxito", R.drawable.boxito));
        listaMascotas.add(new MascotaVo("Cami", R.drawable.cami));
        listaMascotas.add(new MascotaVo("Catty", R.drawable.catty));
        listaMascotas.add(new MascotaVo("Cuqui", R.drawable.cuqui));
        listaMascotas.add(new MascotaVo("Jamon", R.drawable.jamon));
        listaMascotas.add(new MascotaVo("Pepito", R.drawable.pepito));
        listaMascotas.add(new MascotaVo("Ronny", R.drawable.ronny));
    }


}
