package com.example.recyclerviewpersonalizado;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityFavorito extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorito);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
}
